<?php
/**
 * Created by PhpStorm.
 * User: DanielaCarmelina
 * Date: 26/05/2016
 * Time: 2:02
 */?>
<body id="background">
<header class="container hoofding">
    <div id="pxlLine"></div>
    <div class="hidden-xs hidden-sm">
        <img class="col-md-2 " src="<?php echo base_url();?>assets/Pictures/Logo_PXL.png" alt="PXL logo"/>
</nav>
</div>
<div class="hidden-md hidden-lg">
    <div class="navbar navbar-inverse navbar-fixed-top">
        <div class="navbar-header">
            <a class="navbar-brand" href="#">PXL-Ticketing system</a>
        </div>
    </div>
</div>
<div class="col-md-2"></div>

</header>

