<?= link_tag('/assets/bootstrap/css/bootstrap.css') ?>
<footer class="footer col-md-7 col-md-offset-2">
    <p><span class="glyphicon glyphicon-copyright-mark"></span>PXL</p>
</footer>
</body>
</html>