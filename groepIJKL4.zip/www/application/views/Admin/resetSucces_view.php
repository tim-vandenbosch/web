<?php
/**
 * Created by PhpStorm.
 * User: tim_v
 * Date: 24/05/2016
 * Time: 10:15
 */
?>
<div class="col-md-7 col-md-offset-2 titel">
    <h1>Nieuwe user</h1>
</div>
<div class="col-md-7 col-md-offset-2 main home ">
    <div class="col-md-4 left">
        <h2>Succes!</h2>
    </div>
    <div class="col-md-7 right">
        <p>De user is met succes aangepast.</p>
    </div>
</div>